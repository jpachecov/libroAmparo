import java.util.Scanner;
/**
 * Programa sencillo para que envie un mensaje de felicitacion.
 * Objetivo Mostrar el uso del objeto System.out
 * @author  Amparo López Gaona
 * @version Tercera edición
 */
public class Felicitacion {                                    

  public static void main (String [] pps) {       
    System.out.println("!Felicidades! Has escrito tu primer programa en Java.");
  }
}
