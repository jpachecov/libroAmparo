/**
 * Programa sencillo para que envie un mensaje de felicitacion.
 * Objetivo Mostrar como se crean y escriben mensajes en mas de una linea.
 * @author  Amparo López Gaona
 * @version Tercera edición
 */
public class FelicitacionEn2Lineas {                                    

  public static void main (String [] pps) {       

    System.out.println("!Felicidades!");
    System.out.println("\t Has escrito tu primer programa en Java.");
  }
}
