/**
* Interfaz para definir el comportamiento de objetos capaces de hacer clasificaciones
* 
* @author  Amparo López Gaona
* @version Tercera edición
*/
public interface Clasificable{

  public String clasificar();

}
