/**
 * Interfaz inflable
 * @author  Amparo López Gaona
 * @version Tercera edición
 */
public interface Inflable{
    public void inflar(int cuanto);
    public void desinflar(int cuanto);
}
