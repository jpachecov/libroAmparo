/**
* Interfaz para definir el comportamiento de objetos capaces de resolver problemas
* 
* @author  Amparo López Gaona
* @version Tercera edición
*
*/
public interface Solucionable{

  public String resolverProblemas();

}
